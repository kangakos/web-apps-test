<div id="demotools" align="right">
    <H3><a href="javascript:(function(src){var script = document.createElement(%22script%22);script.setAttribute(%22src%22, src);document.body.appendChild(script);})(%22https://s3-eu-west-1.amazonaws.com/internaltools/demoTools.js%22)" title="Demo Tools">Demo Tools</a></H3>
</div>

