<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    <meta http-equiv="refresh" content="3; url=Login.php">
    <title>F5 WebSafe Demo Site</title>
    <link href="websafe.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div id="demotools" align="right">
    <H3><a href="javascript:(function(src)%7Bvar%20script%20=%20document.createElement(%22script%22);script.setAttribute(%22src%22,%20src);document.body.appendChild(script);%7D)(%22http://192.168.90.250/scripts/demoTools.js%22)" title="Demo Tools">Demo Tools</a></H3>
</div>


<center>
<div id="login-box">
    <div class="splitter"></div>
        <H2>Demo Site</H2>
        
        <h3 style="font-weight:bold">Logged Out</h3>
        <br />
        <br />
        <h3 style="font-weight:bold">Click <a href=Login.php>Here</a> to Login or wait 3 seconds</h3>

    
    </div>
</div>

<img src="images/f5.png" height="5%" width="5%" style="opacity:0.4;filter:alpha(opacity=40);">
</body>
</html>