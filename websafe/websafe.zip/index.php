<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 3.2//EN">
<html>
<head>
    <meta http-equiv="refresh" content="0; url=Login.php">

</head>
<body>
</body>
</html>
